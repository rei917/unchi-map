// ============================================================
// components/ui/UserMenu.tsx
// ヘッダー右上のユーザーメニュー
// アバター → ドロップダウン → 表示名変更 / ログアウト
// ============================================================

"use client";

import { useState, useRef, useEffect } from "react";
import { signOut } from "next-auth/react";
import { CurrentUser } from "@/hooks/useCurrentUser";

type Props = {
  user: CurrentUser;
  onUpdateName: (name: string) => void;
};

export default function UserMenu({ user, onUpdateName }: Props) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [nameInput, setNameInput] = useState(user.displayName);
  const menuRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // メニュー外クリックで閉じる
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
        setEditing(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // 編集モードになったらフォーカス
  useEffect(() => {
    if (editing) {
      setNameInput(user.displayName);
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [editing, user.displayName]);

  const handleSaveName = () => {
    if (nameInput.trim()) {
      onUpdateName(nameInput.trim());
    }
    setEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSaveName();
    if (e.key === "Escape") setEditing(false);
  };

  return (
    <div className="user-menu" ref={menuRef}>
      {/* アバターボタン */}
      <button
        className="avatar-btn"
        onClick={() => setOpen((v) => !v)}
        aria-label="ユーザーメニューを開く"
      >
        {user.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={user.image} alt={user.displayName} className="avatar-img" />
        ) : (
          <span className="avatar-fallback">
            {user.displayName.charAt(0)}
          </span>
        )}
      </button>

      {/* ドロップダウン */}
      {open && (
        <div className="user-dropdown">
          {/* ユーザー情報ヘッダー */}
          <div className="dropdown-header">
            {user.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={user.image} alt="" className="dropdown-avatar" />
            ) : (
              <div className="dropdown-avatar-fallback">
                {user.displayName.charAt(0)}
              </div>
            )}
            <div className="dropdown-user-info">
              <p className="dropdown-display-name">{user.displayName}</p>
              {user.email && (
                <p className="dropdown-email">{user.email}</p>
              )}
            </div>
          </div>

          <div className="dropdown-divider" />

          {/* 表示名変更 */}
          <div className="dropdown-section">
            <p className="dropdown-section-label">表示名</p>
            {editing ? (
              <div className="name-edit-row">
                <input
                  ref={inputRef}
                  className="name-input"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  maxLength={20}
                  placeholder="表示名を入力"
                />
                <button className="name-save-btn" onClick={handleSaveName}>
                  保存
                </button>
              </div>
            ) : (
              <button
                className="name-edit-trigger"
                onClick={() => setEditing(true)}
              >
                <span>{user.displayName}</span>
                <span className="edit-icon">✏️</span>
              </button>
            )}
          </div>

          <div className="dropdown-divider" />

          {/* ログアウト */}
          <button
            className="signout-btn"
            onClick={() => signOut({ callbackUrl: "/login" })}
          >
            🚪 ログアウト
          </button>
        </div>
      )}
    </div>
  );
}
